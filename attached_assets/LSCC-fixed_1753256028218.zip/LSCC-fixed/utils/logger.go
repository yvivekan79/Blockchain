package utils

import (
	"log"
	"os"
)

type Logger struct {
	debugLogger *log.Logger
	errorLogger *log.Logger
}

func NewLogger() *Logger {
	return &Logger{
		debugLogger: log.New(os.Stdout, "[DEBUG] ", log.LstdFlags|log.Lshortfile),
		errorLogger: log.New(os.Stderr, "[ERROR] ", log.LstdFlags|log.Lshortfile),
	}
}

// Info logs a message at info level
func (l *Logger) Info(v ...interface{}) {
	l.debugLogger.Println(v...)
}

// Infof logs a formatted message at info level
func (l *Logger) Infof(format string, v ...interface{}) {
	l.debugLogger.Printf(format, v...)
}

// Error logs a message at error level
func (l *Logger) Error(v ...interface{}) {
	l.errorLogger.Println(v...)
}

// Errorf logs a formatted message at error level
func (l *Logger) Errorf(format string, v ...interface{}) {
	l.errorLogger.Printf(format, v...)
}
