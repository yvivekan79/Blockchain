package utils

import (
	"encoding/csv"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"time"
)

func AssignLayer(txType string) string {
	switch txType {
	case "micropayment":
		return "Layer 1"
	case "defi":
		return "Layer 2"
	case "longterm":
		return "Layer 3"
	default:
		return "Layer 3"
	}
}

func LogTransactionMetrics(nodeID, txID, txType, layer string, timestamp int64) {
	metricsDir := filepath.Join("data", "metrics")
	os.MkdirAll(metricsDir, 0755)

	filename := fmt.Sprintf("metrics_node%s.csv", nodeID[len("node"):])
	path := filepath.Join(metricsDir, filename)

	file, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		fmt.Printf("Failed to write metrics: %v\n", err)
		return
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	record := []string{
		txID,
		txType,
		layer,
		strconv.FormatInt(timestamp, 10),
		time.Now().Format(time.RFC3339Nano),
	}
	writer.Write(record)
	writer.Flush()
}
