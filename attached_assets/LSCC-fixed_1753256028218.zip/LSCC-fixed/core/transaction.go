package core

type Transaction struct {
	ID        string `json:"id"`
	From      string `json:"from"`
	To        string `json:"to"`
	Amount    int    `json:"amount"`
	Type      string `json:"type"` // e.g., micropayment, defi, longterm
	Timestamp int64  `json:"timestamp"`
	Layer     string `json:"layer"` // Used in LSCC to tag the transaction
}
