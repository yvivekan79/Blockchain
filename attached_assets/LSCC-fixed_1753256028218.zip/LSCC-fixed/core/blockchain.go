package core

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"

	"lscc/config"
)

type Blockchain struct {
	Blocks []*Block
	Config *config.Config
	lock   sync.Mutex
}

func NewBlockchain(cfg *config.Config) (*Blockchain, error) {
	chain := &Blockchain{
		Blocks: make([]*Block, 0),
		Config: cfg,
	}

	// Load existing blocks if present
	dir := filepath.Join("data", "blocks", cfg.NodeID)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create data directory: %w", err)
	}

	files, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}

	for _, file := range files {
		if !file.IsDir() && filepath.Ext(file.Name()) == ".json" {
			path := filepath.Join(dir, file.Name())
			block, err := LoadBlock(path)
			if err == nil {
				chain.Blocks = append(chain.Blocks, block)
			}
		}
	}

	return chain, nil
}

func (bc *Blockchain) AddBlock(block *Block) {
	bc.lock.Lock()
	defer bc.lock.Unlock()
	bc.Blocks = append(bc.Blocks, block)
}

func (bc *Blockchain) SaveBlockToDisk(block *Block) error {
	dir := filepath.Join("data", "blocks", bc.Config.NodeID)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}

	filename := fmt.Sprintf("block_%05d.json", time.Now().UnixNano()%100000)
	path := filepath.Join(dir, filename)

	data, err := json.MarshalIndent(block, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(path, data, 0644)
}

func (bc *Blockchain) FindTransaction(txID string) *Transaction {
	bc.lock.Lock()
	defer bc.lock.Unlock()

	for _, block := range bc.Blocks {
		if block.Committed {
			for _, tx := range block.Transactions {
				if tx.ID == txID {
					return tx
				}
			}
		}
	}
	return nil
}

func LoadBlock(path string) (*Block, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var block Block
	if err := json.NewDecoder(file).Decode(&block); err != nil {
		return nil, err
	}
	return &block, nil
}
