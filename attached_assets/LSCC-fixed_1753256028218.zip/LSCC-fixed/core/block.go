package core

type BlockHeader struct {
	Timestamp int64    `json:"timestamp"`
	CrossRefs []string `json:"crossRefs"`
	Layer     string   `json:"layer"`
}

type Block struct {
	Hash         string         `json:"hash"`
	Header       BlockHeader    `json:"header"`
	Committed    bool           `json:"committed"`
	Transactions []*Transaction `json:"transactions"`
}
