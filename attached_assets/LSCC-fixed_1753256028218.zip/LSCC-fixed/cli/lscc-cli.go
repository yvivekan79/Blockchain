package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"math/rand"
	"net/http"
	"os"
	"time"
)

type Transaction struct {
	ID        string `json:"id"`
	From      string `json:"from"`
	To        string `json:"to"`
	Amount    int    `json:"amount"`
	Type      string `json:"type"`
	Timestamp int64  `json:"timestamp"`
}

func main() {
	from := flag.String("from", "", "Sender address")
	to := flag.String("to", "", "Recipient address")
	amount := flag.Int("amount", 0, "Amount to send")
	txType := flag.String("type", "micropayment", "Transaction type: micropayment, defi, longterm")
	port := flag.Int("port", 8000, "Node REST port")

	flag.Parse()

	if *from == "" || *to == "" || *amount <= 0 {
		fmt.Println("❌ Error: from, to, and amount are required fields.")
		flag.Usage()
		os.Exit(1)
	}

	tx := Transaction{
		ID:        fmt.Sprintf("tx%d-%d", time.Now().UnixNano(), rand.Intn(1000)),
		From:      *from,
		To:        *to,
		Amount:    *amount,
		Type:      *txType,
		Timestamp: time.Now().Unix(),
	}

	jsonData, err := json.Marshal(tx)
	if err != nil {
		fmt.Printf("Failed to marshal transaction: %v\n", err)
		return
	}

	url := fmt.Sprintf("http://localhost:%d/send", *port)
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		fmt.Printf("Failed to send transaction: %v\n", err)
		return
	}
	defer resp.Body.Close()

	fmt.Printf("✅ Sent transaction to %s. Response: %s\n", url, resp.Status)
}
