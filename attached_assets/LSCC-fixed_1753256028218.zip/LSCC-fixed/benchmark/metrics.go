package benchmark

import (
	"encoding/csv"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"sync"
	"time"
)

type TxMetrics struct {
	TxID      string
	Protocol  string
	Layer     string
	LatencyMs int64
	Timestamp string
}

type Metrics struct {
	mu     sync.Mutex
	values []TxMetrics
	nodeID string
}

func NewMetrics(nodeID string) *Metrics {
	return &Metrics{
		values: make([]TxMetrics, 0),
		nodeID: nodeID,
	}
}

func (m *Metrics) Record(txID, protocol, layer string, latency time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.values = append(m.values, TxMetrics{
		TxID:      txID,
		Protocol:  protocol,
		Layer:     layer,
		LatencyMs: latency.Milliseconds(),
		Timestamp: time.Now().Format(time.RFC3339),
	})
}

func (m *Metrics) ExportCSV() error {
	m.mu.Lock()
	defer m.mu.Unlock()

	folder := "data"
	if err := os.MkdirAll(folder, 0755); err != nil {
		return err
	}

	filename := fmt.Sprintf("metrics_%s.csv", m.nodeID)
	filepath := filepath.Join(folder, filename)

	f, err := os.Create(filepath)
	if err != nil {
		return err
	}
	defer f.Close()

	writer := csv.NewWriter(f)
	defer writer.Flush()

	writer.Write([]string{"txID", "protocol", "layer", "latencyMs", "timestamp"})

	for _, row := range m.values {
		writer.Write([]string{
			row.TxID,
			row.Protocol,
			row.Layer,
			strconv.FormatInt(row.LatencyMs, 10),
			row.Timestamp,
		})
	}

	return nil
}
