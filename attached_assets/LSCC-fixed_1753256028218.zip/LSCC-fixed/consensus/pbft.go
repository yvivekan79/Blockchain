package consensus

import (
	"fmt"
	"lscc/core"
	"lscc/utils"
)

type PBFT struct{}

func NewPBFTConsensus(difficulty int, logger utils.Logger) *PBFT {
	return &PBFT{}
}

func (p *PBFT) FinalizeConsensus(block *core.Block) bool {
	fmt.Printf("[PBFT] reached consensus on block: %s\n", block.Hash)
	return true
}
