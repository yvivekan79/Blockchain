package consensus

import (
	"fmt"
	"lscc/core"
	"lscc/utils"
	"math/rand"
)

type PoS struct{}

func NewPoSConsensus(difficulty int, logger utils.Logger) *PoS {
	return &PoS{}
}

func (p *PoS) FinalizeConsensus(block *core.Block) bool {
	if rand.Float32() < 0.95 {
		fmt.Printf("[PoS] block finalized: hash=%s\n", block.Hash)
		return true
	}
	return false
}
