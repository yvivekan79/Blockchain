package consensus

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"lscc/core"
	"lscc/utils"
	"math/rand"
	"strconv"
	"strings"
)

type PoW struct {
	Difficulty int
}

func NewPoWConsensus(difficulty int, logger utils.Logger) *PoW {
	return &PoW{Difficulty: difficulty}
}

func (p *PoW) FinalizeConsensus(block *core.Block) bool {
	prefix := strings.Repeat("0", p.Difficulty)
	nonce := rand.Intn(1000)

	for {
		input := block.Hash + strconv.Itoa(nonce)
		hash := sha256.Sum256([]byte(input))
		hashStr := hex.EncodeToString(hash[:])
		if strings.HasPrefix(hashStr, prefix) {
			block.Hash = hashStr
			fmt.Printf("[PoW] block mined: nonce=%d, hash=%s\n", nonce, hashStr)
			return true
		}
		nonce++
		if nonce > 100000 {
			return false
		}
	}
}
