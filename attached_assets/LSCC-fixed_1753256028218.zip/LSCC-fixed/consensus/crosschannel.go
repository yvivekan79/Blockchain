package consensus

import (
	"fmt"
	"lscc/core"
	"lscc/utils"
)

type CrossChannelConsensus struct {
	Blockchain *core.Blockchain
}

func NewCrossChannelConsensus(difficulty int, logger utils.Logger, bc *core.Blockchain) *CrossChannelConsensus {
	return &CrossChannelConsensus{
		Blockchain: bc,
	}
}

func (ccc *CrossChannelConsensus) FinalizeConsensus(block *core.Block) bool {
	if block.Header.Layer == "" {
		block.Header.Layer = "Layer 3"
	}

	block.Header.CrossRefs = []string{
		fmt.Sprintf("ref-%s--L1", block.Hash),
		fmt.Sprintf("ref-%s--L2", block.Hash),
		fmt.Sprintf("ref-%s--L3", block.Hash),
	}

	fmt.Printf("[LSCC] finalized cross-layer block: %s with refs: %v\n", block.Hash, block.Header.CrossRefs)
	return true
}
