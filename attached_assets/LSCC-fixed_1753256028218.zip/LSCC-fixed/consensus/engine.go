package consensus

import (
	"lscc/config"
	"lscc/core"
	"lscc/utils"
)

// SelectEngine returns the appropriate consensus engine.
func SelectEngine(cfg *config.Config, logger *utils.Logger, bc *core.Blockchain) ConsensusEngine {
	switch cfg.Consensus {
	case "pow":
		return NewPoWConsensus(cfg.ConsensusDifficulty, *logger)
	case "pos":
		return NewPoSConsensus(cfg.ConsensusDifficulty, *logger)
	case "pbft":
		return NewPBFTConsensus(cfg.ConsensusDifficulty, *logger)
	case "lscc":
		return NewCrossChannelConsensus(cfg.ConsensusDifficulty, *logger, bc)
	default:
		logger.Error("Unknown consensus: %s, defaulting to PoW", cfg.Consensus)
		return NewPoWConsensus(cfg.ConsensusDifficulty, *logger)
	}
}
