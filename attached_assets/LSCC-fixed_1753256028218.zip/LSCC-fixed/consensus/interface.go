package consensus

import "lscc/core"

// ConsensusEngine defines the standard interface that
// all consensus mechanisms must implement.
type ConsensusEngine interface {
	FinalizeConsensus(block *core.Block) bool
}
