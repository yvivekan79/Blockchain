#!/bin/bash

echo Running LSCC nodes...

mkdir -p logs

echo "Launching node1 on port 8000"
./lscc --config=config/config_node1.json > logs/node1.log 2>&1 &

echo "Launching node2 on port 8001"
./lscc --config=config/config_node2.json > logs/node2.log 2>&1 &

echo "Launching node3 on port 8002"
./lscc --config=config/config_node3.json > logs/node3.log 2>&1 &
