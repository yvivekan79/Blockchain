# LSCC Code Mapping Report

This document maps the **LSCC source code** to the corresponding sections of the paper *"Scaling_issues_and_solutions (3).pdf"*. It includes implementation references for Cross-Channel Consensus (CCC), Layered Sharding, benchmarking, and simulation tools.

---

## 📌 Section 4: Proposed Hybrid Solution - LSCC

- **File(s)**:
  - `sharding/shard.go`
  - `sharding/cross_channel.go`
  - `consensus/crosschannel.go`

- **Concepts Implemented**:
  - Layered Sharding with Layer IDs (`Shard.Layer`)
  - Cross-reference structure (`CrossReference`)
  - Cross-Channel Consensus stub with commit/abort logic

---

## 📌 Section 5: Detailed LSCC Explanation

- **Routing Logic**:
  - `shard.go`: `RouteTransaction()` assigns transaction to the correct layer
  - `SelectRelayNode()` locates inter-layer relay node

- **Consensus Protocol**:
  - `crosschannel.go`: `ValidateTransactionWithVoting()`, `FinalizeConsensus()` implements single-round CCC

- **Relay Node Behavior**:
  - Relay node flag in `Shard` (`Relay: true`)
  - Usage in routing coordination

---

## 📌 Section 6: CCC Protocol Algorithm

- **Implemented In**:
  - `consensus/crosschannel.go` – Consensus voting logic
  - `network/rest.go` – Triggers CCC when transactions arrive via `/send`

- **Simulated Block Processing**:
  - REST uses `MockBlock` to test CCC logic

---

## 📌 Section 7: Mathematical Performance – Benchmarking

- **File**: `benchmark/metrics.go`
- **Functions**:
  - `Record(txID, time.Time)` logs latency
  - `ExportCSV("metrics.csv")` outputs CSV for throughput analysis

---

## 📌 Section 9: Comparison and Simulation

- **Multi-node Setup**:
  - `nodes.json`: Defines node layers, shard IDs, and ports
  - `run-nodes.sh`: Launches 3 LSCC nodes in parallel
  - `config/config_node*.json`: Config files for each node

- **CLI Simulation**:
  - `lscc-cli.go`: Sends transactions with `-from`, `-to`, `-amount`, `-port`
  - Interacts with REST `/send` endpoint for transaction handling

---

## 🔧 Utility Scripts

- **`run-nodes.sh`**: Parallel startup for 3-node simulation
- **`lscc-cli.go`**: Sends transactions
- **`rest.go`**: Handles `/send` and `/metrics` endpoints

---

## ✅ Features Implemented Summary

| Feature                | Status |
|------------------------|--------|
| Cross-Channel Consensus | ✅ Complete |
| Layered Sharding        | ✅ Complete |
| Relay Nodes             | ✅ Active |
| CLI + REST Simulation   | ✅ Working |
| Benchmarking            | ✅ Export to CSV |
| Multi-node Support      | ✅ 3-layer setup |

---

## 🧩 Next Steps (Future Work)

- Replace `MockBlock` with real block object from `core/block.go`
- Extend CCC to support actual validator communication
- Integrate with real peer-to-peer and consensus transport layer
