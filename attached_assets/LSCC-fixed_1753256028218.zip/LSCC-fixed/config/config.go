package config

import (
	"encoding/json"
	"os"
)

type Config struct {
	NodeID              string   `json:"nodeID"`
	Port                int      `json:"port"`
	ShardID             int      `json:"shardID"`
	Layer               int      `json:"layer"`
	IsRelay             bool     `json:"isRelay"`
	Peers               []string `json:"peers"`
	Consensus           string   `json:"consensus"`
	ConsensusDifficulty int      `json:"consensusDifficulty"`
	LogLevel            string   `json:"logLevel"`
}

func LoadConfig(file string) (*Config, error) {
	f, err := os.Open(file)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	decoder := json.NewDecoder(f)
	var cfg Config
	err = decoder.Decode(&cfg)
	return &cfg, err
}
