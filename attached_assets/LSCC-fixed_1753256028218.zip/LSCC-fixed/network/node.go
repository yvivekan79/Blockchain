package network

import (
	"fmt"
	"lscc/config"
	"lscc/consensus"
	"lscc/core"
	"lscc/utils"
)

// NewNode initializes a new blockchain node.
func NewNode(cfg *config.Config) (*Node, error) {
	logger := utils.NewLogger()

	// Initialize the blockchain
	blockchain, err := core.NewBlockchain(cfg)
	if err != nil {
		logger.Error("Failed to initialize blockchain: %v", err)
		return nil, err
	}

	// Initialize consensus engine
	var engine consensus.ConsensusEngine
	switch cfg.Consensus {
	case "pow":
		engine = consensus.NewPoWConsensus(cfg.ConsensusDifficulty, *logger)
	case "lscc":
		engine = consensus.NewCrossChannelConsensus(cfg.ConsensusDifficulty, *logger, blockchain)
	default:
		err := fmt.Errorf("unsupported consensus: %s", cfg.Consensus)
		logger.Errorf("Unsupported consensus: %s, error: %v", cfg.Consensus, err)
		return nil, err
	}

	node := &Node{
		Config:     cfg,
		Consensus:  engine,
		Blockchain: blockchain,
		Mempool:    NewMempool(),
		Logger:     logger,
	}

	return node, nil
}

// InitializeNode initializes a node using the provided configuration.
// Replace the implementation with your actual logic.
func InitializeNode(cfg *config.Config) (interface{}, error) {
	// TODO: Implement node initialization logic here.
	return nil, nil
}
