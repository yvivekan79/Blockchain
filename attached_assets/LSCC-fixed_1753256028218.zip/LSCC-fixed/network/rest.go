package network

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"runtime/pprof"
	"strconv"
	"time"

	"lscc/config"
	"lscc/consensus"
	"lscc/core"
	"lscc/utils"

	"github.com/gorilla/mux"
)

type Node struct {
	Config     *config.Config
	Consensus  consensus.ConsensusEngine
	Blockchain *core.Blockchain
	Mempool    *Mempool
	Logger     *utils.Logger
}

func StartServer(cfg *config.Config, engine consensus.ConsensusEngine, bc *core.Blockchain, logger *utils.Logger) {
	node := &Node{
		Config:     cfg,
		Consensus:  engine,
		Blockchain: bc,
		Mempool:    NewMempool(),
		Logger:     logger,
	}

	r := mux.NewRouter()
	r.HandleFunc("/send", node.handleSend).Methods("POST")
	r.HandleFunc("/status", node.handleStatus).Methods("GET")
	r.HandleFunc("/pprof", node.handlePprof).Methods("GET")

	addr := fmt.Sprintf(":%d", cfg.Port)
	node.Logger.Infof("REST API listening on %s", addr)

	if err := http.ListenAndServe(addr, r); err != nil {
		node.Logger.Errorf("REST server error: %v", err)
		os.Exit(1)
	}
}

func (n *Node) handleSend(w http.ResponseWriter, r *http.Request) {
	var tx core.Transaction

	if err := json.NewDecoder(r.Body).Decode(&tx); err != nil {
		http.Error(w, "invalid transaction format", http.StatusBadRequest)
		return
	}

	// Generate unique ID if not provided
	if tx.ID == "" {
		tx.ID = "tx" + strconv.FormatInt(time.Now().UnixNano(), 10)
	}

	tx.Timestamp = time.Now().Unix()
	tx.Layer = utils.AssignLayer(tx.Type)
	n.Mempool.Add(&tx)

	utils.LogTransactionMetrics(n.Config.NodeID, tx.ID, tx.Type, tx.Layer, tx.Timestamp)

	// Build block from transaction
	block := &core.Block{
		Transactions: []*core.Transaction{&tx},
		Header: core.BlockHeader{
			Timestamp: tx.Timestamp,
			Layer:     tx.Layer,
		},
	}

	if err := n.Consensus.FinalizeConsensus(block); err != true {
		http.Error(w, "consensus failure", http.StatusInternalServerError)
		return
	}

	block.Committed = true
	n.Blockchain.AddBlock(block)

	// Save block to disk
	if err := n.Blockchain.SaveBlockToDisk(block); err != nil {
		n.Logger.Errorf("Failed to save block: %v", err)
	}

	n.Logger.Infof("Transaction processed: ID=%s, Consensus=%s", tx.ID, n.Config.Consensus)

	resp := map[string]string{
		"status":        "committed",
		"transactionID": tx.ID,
		"consensus":     n.Config.Consensus,
		"blockHash":     block.Hash,
	}
	json.NewEncoder(w).Encode(resp)
}

func (n *Node) handleStatus(w http.ResponseWriter, r *http.Request) {
	txID := r.URL.Query().Get("id")
	if txID == "" {
		http.Error(w, "missing id param", http.StatusBadRequest)
		return
	}

	tx, exists := n.Mempool.Get(txID)
	status := "pending"
	if !exists {
		if committedTx := n.Blockchain.FindTransaction(txID); committedTx != nil {
			tx = committedTx
			status = "committed"
		}
	}

	if tx == nil {
		http.Error(w, "transaction not found", http.StatusNotFound)
		return
	}

	resp := map[string]interface{}{
		"status":        status,
		"transactionID": tx.ID,
		"from":          tx.From,
		"to":            tx.To,
		"amount":        tx.Amount,
		"type":          tx.Type,
		"layer":         tx.Layer,
		"consensus":     n.Config.Consensus,
	}
	json.NewEncoder(w).Encode(resp)
}

func (n *Node) handlePprof(w http.ResponseWriter, r *http.Request) {
	profile := r.URL.Query().Get("profile")
	if profile == "" {
		profile = "goroutine"
	}
	pprof.Lookup(profile).WriteTo(w, 1)
}
func (n *Node) GetConfig() *config.Config {
	return n.Config
}
