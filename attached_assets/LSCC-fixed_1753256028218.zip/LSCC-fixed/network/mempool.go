package network

import (
	"sync"

	"lscc/core"
)

// Mempool is a thread-safe transaction pool that stores unconfirmed transactions.
// It supports indexing by transaction ID and layer/type assignment if required.
type Mempool struct {
	pool map[string]*core.Transaction
	mu   sync.RWMutex
}

// NewMempool initializes a new mempool instance.
func NewMempool() *Mempool {
	return &Mempool{
		pool: make(map[string]*core.Transaction),
	}
}

// Add inserts a transaction into the mempool.
func (m *Mempool) Add(tx *core.Transaction) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.pool[tx.ID] = tx
}

// Get returns a transaction by ID.
func (m *Mempool) Get(id string) (*core.Transaction, bool) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	tx, ok := m.pool[id]
	return tx, ok
}

// Delete removes a transaction by ID.
func (m *Mempool) Delete(id string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.pool, id)
}

// All returns a copy of all transactions.
func (m *Mempool) All() []*core.Transaction {
	m.mu.RLock()
	defer m.mu.RUnlock()
	txs := make([]*core.Transaction, 0, len(m.pool))
	for _, tx := range m.pool {
		txs = append(txs, tx)
	}
	return txs
}

// Exists checks whether a transaction exists by ID.
func (m *Mempool) Exists(id string) bool {
	m.mu.RLock()
	defer m.mu.RUnlock()
	_, exists := m.pool[id]
	return exists
}

// Len returns the number of transactions in the pool.
func (m *Mempool) Len() int {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.pool)
}

// Clear empties the mempool completely.
func (m *Mempool) Clear() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.pool = make(map[string]*core.Transaction)
}
