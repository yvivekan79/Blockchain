package main

import (
	"fmt"
	"lscc/config"
	"lscc/consensus"
	"lscc/core"
	"lscc/network"
	"lscc/utils"
	"os"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: lscc.exe --config=config/config_nodeX.json")
		os.Exit(1)
	}

	cfgPath := ""
	if os.Args[1] == "--config" && len(os.Args) >= 3 {
		cfgPath = os.Args[2]
	} else {
		fmt.Println("Invalid command. Use --config <path>")
		os.Exit(1)
	}

	fmt.Printf("Loading config from: %s\n", cfgPath)

	cfg, err := config.LoadConfig(cfgPath)
	if err != nil {
		fmt.Printf("Error loading config: %v\n", err)
		os.Exit(1)
	}

	logger := utils.NewLogger()
	blockchain, err := core.NewBlockchain(cfg)
	if err != nil {
		logger.Errorf("Failed to initialize blockchain: %v", err)
		os.Exit(1)
	}

	consensusEngine := consensus.SelectEngine(cfg, logger, blockchain)

	logger.Infof("Starting node %s on port %d...", cfg.NodeID, cfg.Port)
	network.StartServer(cfg, consensusEngine, blockchain, logger)
}
